import logo from './logo.svg';
import './App.css';
import Dropdown from './components/colorchanger';
function App() {
  return (
    <div className="App">
      <Dropdown />
    </div>
  );
}

export default App;
