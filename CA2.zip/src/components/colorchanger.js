import { React, useState } from 'react';
import Select from 'react-select';
import './colorchanger.css';
function Dropdown ()

{
    const colors = [
        {
            id: 1,
            label: "lime",
            value:"lime"
        },
        
        {
            id: 2,
            label: "lavender",
            value:"lavender"
        },

        {
            id: 3,
            label: "crimson",
            value:"crimson"
        },

        {
            id: 4,
            label: "darkblue",
            value:"darkblue"
        },

        {
            id: 5,
            label: "teal",
            value:"teal"
        },

        {
            id: 6,
            label: "rebeccapurple",
            value:"rebeccapurple"
        },

        {
            id: 7,
            label: "ghostwhite",
            value:"ghostwhite"
        },

        {
            id: 8,
            label: "aquamarine",
            value:"aquamarine"
        },
        {
            id: 9,
            label: "aliceblue",
            value:"aliceblue"
        },
    ]

    const [color, setColor] = useState("");

    const click = (event) => {
        setColor(event.label);
    }
    return (
        <div className='dropdownWrapper'>
            <style>
            {
                `.button 
                {
                 background-color:` + color +';'
                }
            </style>

            <center>
            <h1>Color Changer</h1>
            </center>
            
            <div className="dropdownContainer">
                <Select options={colors} onChange={click} className='select' placeholder="Select Color"></Select>
            </div>
            <div className="block">
                <center>
                    <button className='button'></button>
                </center>
            </div>
        </div>

    );
}
export default Dropdown;